Dashboard-using-D3.js
=====================

Dashboard using bootstrap , D3.js , javascript

This dashboard has 4 tabs i.e

  a) Overall Level <p>
  
In the overall level it has 3 graphs one has time graph which represent the overall store vs date . It has a dropdown option 
so that you can choose 
  b) Store Level <p>
  c) Product Level <p>
  d) Region Level <p>
  
  
  


